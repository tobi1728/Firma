﻿using Firma.Intranet.Models;
using System.ComponentModel.DataAnnotations;

public class HorseCheckup
{
    public int Id { get; set; }

    [Required]
    public int HorseId { get; set; }

    [Required]
    [DataType(DataType.Date)]
    public DateTime CheckupDate { get; set; }

    [Required]
    public string Type { get; set; }

    public string? Notes { get; set; }

    public Horse Horse { get; set; }
}
