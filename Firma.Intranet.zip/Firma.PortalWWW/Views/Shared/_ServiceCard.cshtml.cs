using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Firma.PortalWWW.Views.Shared
{
    public class _ServiceCardModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
